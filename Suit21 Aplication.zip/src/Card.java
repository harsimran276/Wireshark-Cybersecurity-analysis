class Card {
    private String rank;
    private String suit;

    public Card(String rank, String suit) {
        this.rank = rank;
        this.suit = suit;
    }

    public int getValue() {
        if (rank.equals("Jack") || rank.equals("Queen") || rank.equals("King")) return 10;
        if (rank.equals("Ace")) return 11;
        return Integer.parseInt(rank);
    }

    public String getSuit() { return suit; }

    @Override
    public String toString() {
        return rank + " of " + suit;
    }
}
