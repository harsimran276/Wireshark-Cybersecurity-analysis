import org.junit.Test;
import static org.junit.Assert.*;

public class PlayerTest {

    @Test
    public void testDealCard() {
        Player player = new Player("Test Player");
        Card card = new Card("7", "Diamonds");
        player.dealCard(card);

        assertEquals(1, player.getHand().size());
        assertTrue(player.getHand().contains(card));
    }

    @Test
    public void testSwapCard() {
        Player player = new Player("Test Player");
        player.dealCard(new Card("2", "Hearts"));
        player.dealCard(new Card("King", "Spades"));
        Card newCard = new Card("10", "Clubs");

        player.swapCard(1, newCard);

        assertEquals("10 of Clubs", player.getHand().get(1).toString());
    }

    @Test
    public void testCalculateMaxScore() {
        Player player = new Player("Test Player");
        player.dealCard(new Card("2", "Hearts"));
        player.dealCard(new Card("King", "Hearts"));
        player.dealCard(new Card("9", "Hearts"));

        assertEquals(21, player.calculateMaxScore());
    }

    @Test
    public void testPlayerPoints() {
        Player player = new Player("Test Player");
        player.addPoint();
        player.addPoint();
        assertEquals(2, player.getPoints());
    }
}
