import java.util.*;
import java.io.*;
import java.io.File;

public class Suit21Game {
    private List<Player> players = new ArrayList<>();
    private Deck deck = new Deck();
    private List<String> replayLog = new ArrayList<>();

    public List<String> getReplayLog() {
        return replayLog;
    }


    public void addToReplayLog(String action) {
        replayLog.add(action);
    }

    public void startGame() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Suit 21! The card game where strategy meets chance.");

        System.out.print("How many players will join the game? (2-6): ");
        int numPlayers = Integer.parseInt(scanner.nextLine());
        while (numPlayers < 2 || numPlayers > 6) {
            System.out.print("Invalid input. Enter a number between 2 and 6: ");
            numPlayers = Integer.parseInt(scanner.nextLine());
        }

        for (int i = 1; i <= numPlayers; i++) {
            System.out.print("Enter Player " + i + "'s name (type 'Computer' for an AI opponent): ");
            players.add(new Player(scanner.nextLine()));
        }

        System.out.print("How many games would you like to play? ");
        int numGames = Integer.parseInt(scanner.nextLine());

        for (int game = 1; game <= numGames; game++) {
            System.out.println("\nStarting Game " + game + "...");
            dealInitialCards();
            playRounds(scanner);
            deck = new Deck();
        }

        displayFinalScores();

        System.out.print("Would you like to view the replay of the game? (yes/no): ");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            viewReplay();
        }

        System.out.println("Thank you for playing Suit 21! Goodbye!");
    }

    public void dealInitialCards() {
        for (Player player : players) {
            System.out.println("Dealing cards to " + player.getName());
            for (int i = 0; i < 5; i++) {
                Card card = deck.deal();
                if (card != null) {
                    player.dealCard(card);
                } else {
                    System.out.println("Deck ran out of cards while dealing!");
                }
            }
            System.out.println(player);
        }
    }

    private void playRounds(Scanner scanner) {
        while (deck.size() >= players.size()) {
            for (Player player : players) {
                System.out.println("\n" + player);
                System.out.println("Maximum score you can achieve in a single suit: " + player.calculateMaxScore());

                if (player.getName().equalsIgnoreCase("Computer")) {
                    computerDecision(player);
                } else {
                    System.out.print("Enter the index (0-4) of the card you want to swap, or -1 to keep your hand: ");
                    int index = Integer.parseInt(scanner.nextLine());
                    if (index != -1) {
                        Card newCard = deck.deal();
                        player.swapCard(index, newCard);
                        System.out.println("You swapped your card with: " + newCard);
                    }
                }

                replayLog.add(player.getName() + "'s hand: " + player.getHand() + " | Max Score: " + player.calculateMaxScore());
            }
            if (checkForWinner()) break;
        }
    }

    private void computerDecision(Player player) {
        int bestIndex = 0;
        int bestScore = player.calculateMaxScore();
        for (int i = 0; i < player.getHand().size(); i++) {
            List<Card> simulatedHand = new ArrayList<>(player.getHand());
            simulatedHand.remove(i);
            simulatedHand.add(deck.deal());
            int simulatedScore = calculateSimulatedScore(simulatedHand);
            if (simulatedScore > bestScore) {
                bestScore = simulatedScore;
                bestIndex = i;
            }
        }
        Card newCard = deck.deal();
        player.swapCard(bestIndex, newCard);
        System.out.println("Computer swapped a card at index " + bestIndex + " with: " + newCard);
    }

    private int calculateSimulatedScore(List<Card> hand) {
        Map<String, Integer> suitScores = new HashMap<>();
        for (Card card : hand) {
            int value = card.getValue();
            String suit = card.getSuit();
            suitScores.put(suit, suitScores.getOrDefault(suit, 0) + value);
        }
        return suitScores.values().stream().max(Integer::compare).orElse(0);
    }

    private boolean checkForWinner() {
        List<Player> winners = new ArrayList<>();
        for (Player player : players) {
            if (player.calculateMaxScore() == 21) winners.add(player);
        }
        if (!winners.isEmpty()) {
            System.out.println("\nWinner(s) this round: " + winners);
            winners.forEach(Player::addPoint);
            return true;
        }
        return false;
    }

    private void displayFinalScores() {
        players.sort((p1, p2) -> p2.getPoints() - p1.getPoints());
        System.out.println("\nFinal Scores:");
        for (Player player : players) {
            System.out.println(player.getName() + " - " + player.getPoints() + " points");
        }
    }

    private void viewReplay() {
        System.out.println("\nGame Replay:");
        for (String log : replayLog) {
            System.out.println(log);
        }
    }


    public static void main(String[] args) {
        new Suit21Game().startGame();
    }


    public void addPlayer(Player player) {
        if (player != null) {
            players.add(player);
        }
    }

    public List<Player> getPlayers() {
        return players;
    }


    public void saveSummaryToFile() {
        try {
            System.out.println("Saving game summary to a file...");
            File file = new File("game_summary.txt");
            PrintWriter writer = new PrintWriter(file);
            writer.println("Game Summary");
            writer.println("===============");
            for (Player player : players) {
                writer.println("Player: " + player.getName());
                writer.println("Total Points: " + player.getPoints());
            }
            writer.close();
            System.out.println("Game summary saved to: " + file.getAbsolutePath());
        } catch (Exception e) {
            System.out.println("An error occurred while saving the summary: " + e.getMessage());
        }
    }

}




