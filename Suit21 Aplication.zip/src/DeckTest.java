import org.junit.Test;
import static org.junit.Assert.*;

public class DeckTest {

    @Test
    public void testDeckSizeAfterInitialization() {
        Deck deck = new Deck();
        assertEquals(52, deck.size());
    }

    @Test
    public void testDeckDealing() {
        Deck deck = new Deck();
        Card card = deck.deal();
        assertNotNull(card);
        assertEquals(51, deck.size());
    }

    @Test
    public void testDeckEmpty() {
        Deck deck = new Deck();
        for (int i = 0; i < 52; i++) {
            deck.deal();
        }
        assertEquals(0, deck.size());
        assertNull(deck.deal());
    }

    @Test
    public void testAddCardToTop() {
        Deck deck = new Deck();
        Card card = new Card("Ace", "Spades");
        deck.addCardToTop(card);
        assertEquals(53, deck.size());
        assertEquals(card, deck.deal());
    }
}
