import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;
import java.io.File;



    public class Suit21GameTest {

        @Test
        public void testAddToReplayLog() {
            // Initialize Suit21Game
            Suit21Game game = new Suit21Game();

            // Add actions to the replay log
            game.addToReplayLog("Player1 swapped a card.");
            game.addToReplayLog("Player2 kept their hand.");

            // Verify the replay log size and content
            List<String> replayLog = game.getReplayLog();
            assertEquals(2, replayLog.size());
            assertEquals("Player1 swapped a card.", replayLog.get(0));
            assertEquals("Player2 kept their hand.", replayLog.get(1));
        }

        @Test
        public void testAIPlayerDecision() {
            // Set up a computer player and give it some cards
            Player aiPlayer = new Player("Computer");
            aiPlayer.dealCard(new Card("2", "Hearts"));
            aiPlayer.dealCard(new Card("4", "Hearts"));
            aiPlayer.dealCard(new Card("6", "Hearts"));
            aiPlayer.dealCard(new Card("8", "Diamonds"));
            aiPlayer.dealCard(new Card("Ace", "Clubs"));

            // Set up a deck with a card that will improve the AI's score
            Deck deck = new Deck();
            Card highCard = new Card("10", "Hearts");
            deck.addCardToTop(highCard);

            // Simulate the AI decision (swapping the weakest card)
            aiPlayer.swapCard(3, deck.deal());

            // Verify that the high card is now in the AI's hand
            assertTrue(aiPlayer.getHand().contains(highCard));
        }

        @Test
        public void testDealInitialCards() {
            // Initialize the game
            Suit21Game game = new Suit21Game();
            game.addPlayer(new Player("Player1"));
            game.addPlayer(new Player("Player2"));

            // Deal cards
            game.dealInitialCards();

            // Verify that each player has exactly 5 cards
            for (Player player : game.getPlayers()) {
                assertEquals(5, player.getHand().size());
            }
        }

        @Test
        public void testCalculateWinner() {
            // Create two players with known scores
            Player player1 = new Player("Player1");
            Player player2 = new Player("Player2");

            player1.dealCard(new Card("10", "Hearts"));
            player1.dealCard(new Card("Ace", "Hearts"));
            player2.dealCard(new Card("9", "Clubs"));
            player2.dealCard(new Card("King", "Clubs"));

            // Verify scores
            assertEquals(21, player1.calculateMaxScore());
            assertEquals(19, player2.calculateMaxScore());
        }


        @Test
        public void testSaveSummaryToFile() {
            // Create a Suit21Game instance
            Suit21Game game = new Suit21Game();


            Player player1 = new Player("Player1");
            Player player2 = new Player("Player2");
            player1.addPoint();
            player2.addPoint();
            player2.addPoint();

            game.addPlayer(player1);
            game.addPlayer(player2);


            game.saveSummaryToFile();


            File file = new File("game_summary.txt");
            System.out.println("Looking for file at: " + file.getAbsolutePath());
            assertTrue("File not found: game_summary.txt", file.exists());

            if (file.exists()) {
                file.delete();
            }
        }

    }


