import java.util.*;
import java.io.*;
class Player {
    private String name;
    private List<Card> hand = new ArrayList<>();
    private int points = 0;

    public Player(String name) { this.name = name; }

    public void dealCard(Card card) { if (card != null) hand.add(card); }

    public void swapCard(int index, Card newCard) {
        if (index >= 0 && index < hand.size() && newCard != null) hand.set(index, newCard);
    }

    public int calculateMaxScore() {
        Map<String, Integer> suitScores = new HashMap<>();
        for (Card card : hand) {
            int value = card.getValue();
            String suit = card.getSuit();
            suitScores.put(suit, suitScores.getOrDefault(suit, 0) + value);
        }
        return suitScores.values().stream().max(Integer::compare).orElse(0);
    }

    public String getName() { return name; }

    public List<Card> getHand() { return hand; }

    public void addPoint() { points++; }

    public int getPoints() { return points; }


    public String toString() {
        if (hand.isEmpty()) {
            return name + "'s hand is empty.";
        }
        return name + "'s hand: " + hand;
    }
}
