static void main(String[] args) {
  println "Hello world!"
}