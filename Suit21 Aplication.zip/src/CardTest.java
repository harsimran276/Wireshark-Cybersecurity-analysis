import org.junit.Test;
import static org.junit.Assert.*;

public class CardTest {

    @Test
    public void testCardValue() {
        Card card1 = new Card("Ace", "Hearts");
        Card card2 = new Card("King", "Spades");
        Card card3 = new Card("5", "Diamonds");

        assertEquals(11, card1.getValue());
        assertEquals(10, card2.getValue());
        assertEquals(5, card3.getValue());
    }

    @Test
    public void testCardToString() {
        Card card = new Card("Queen", "Hearts");
        assertEquals("Queen of Hearts", card.toString());
    }

    @Test
    public void testCardSuit() {
        Card card = new Card("7", "Clubs");
        assertEquals("Clubs", card.getSuit());
    }
}
